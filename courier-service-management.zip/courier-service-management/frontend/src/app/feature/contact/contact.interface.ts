export interface Contact {
  _id: string;
  lastName: string;
  mobile: string;
  workPhone: string;
  email: string;
}
