﻿export { AuthGuard } from "./auth.guard";
