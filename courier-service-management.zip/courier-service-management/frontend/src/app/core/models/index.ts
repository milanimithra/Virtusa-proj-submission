﻿export * from "./user.interface";
